package com.timmyg.librariesproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.timmyg.librariesproject.Presenter.RecyclerPresenter;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private RecyclerPresenter recyclerPresenter;

    public MyAdapter(RecyclerPresenter recyclerPresenter) {
        this.recyclerPresenter = recyclerPresenter;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
    recyclerPresenter.bindView(holder);
    holder.position = position;
    }

    @Override
    public int getItemCount() {
        return recyclerPresenter.getItemCount();
    }


    class MyViewHolder extends RecyclerView.ViewHolder implements IViewHolder {

        private ImageView imageView;
        private int position = 0;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.item_image_view);
        }

        @Override
        public void setImage(int image) {
            imageView.setImageResource(image);
        }

        @Override
        public int getPos() {
            return position;
        }
    }


}
