package com.timmyg.librariesproject;

public interface IViewHolder {
    void setImage(int image);
    int getPos();
}
